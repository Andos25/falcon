#!/usr/bin/Rscript

install.packages("rJava")
install.packages("Rserve")
install.packages("RUnit")
